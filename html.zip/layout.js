var doLayout = function () {
isIE = false;
if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)){ //test for MSIE x.x;
	isIE = true;
};

if (isIE) {
		var doc = document.getElementsByTagName("body").item(0);
		var obj = document.getElementById("all");
		var bg = document.getElementById("background");
		var wa = doc.clientWidth;
		// set width of content
		obj.style.width = wa*0.7;
		obj.style.marginLeft = 0.15*wa;
		obj.style.marginRight = 0.15*wa;
		// set size of bg according to content size
		bg.style.height = obj.clientHeight;
		bg.style.width = obj.clientWidth;
		var ha = obj.clientHeight;
		wa = obj.clientWidth;
		
		// set table cell sizes
		var w = wa*0.8;
		var h = 0;
		
		obj = document.getElementsByTagName("table");
		
		var i=0;
		var p1=0;
		var p2=1;
		var chd = null;
		var mh = 0;
		
		for (i=0;i<obj.length;i++) {
			if (obj.item(i).className == "feature" && obj.item(i).id != "noresize") {
				if (obj.item(i).children(0).children(0).children(0).id == "tleft") {
					p1 = 0;
					p2 = 1;
				} else {
					p1 = 1;
					p2 = 0;
				};
				
				// resize cells to text (2/3) img (1/3)
				obj.item(i).children(0).children(0).children(p2).style.width = w*1/3;
//				obj.item(i).children(0).children(0).children(p2).children(0).style.width = w*1/3;
				obj.item(i).children(0).children(0).children(p1).style.width = w*2/3;
				
				if (obj.item(i).id != "cmplx") {
					// set image width if too large
					if (obj.item(i).children(0).children(0).children(p2).children(0).clientWidth > w*1/3) {
						obj.item(i).children(0).children(0).children(p2).children(0).style.width = w*1/3;
					}
				}
				
				// set cell padding
				obj.item(i).children(0).children(0).children(p1).style.padding = w*0.025;
				obj.item(i).children(0).children(0).children(p2).style.padding = w*0.025;
				
				// reset top and bottom paddings
				obj.item(i).children(0).children(0).children(p1).style.paddingTop = 0;
				obj.item(i).children(0).children(0).children(p2).style.paddingTop = 0;
				obj.item(i).children(0).children(0).children(p1).style.paddingBottom = 0;
				obj.item(i).children(0).children(0).children(p2).style.paddingBottom = 0;
					
				// set cell heights equal 
				h = obj.item(i).children(0).children(0).children(p1).clientHeight;
				obj.item(i).children(0).children(0).children(0).style.height = h;
				obj.item(i).children(0).children(0).children(1).style.height = h;
					
				if (obj.item(i).id != "cmplx") {
					// move image to middle of cell
					h = (h - obj.item(i).children(0).children(0).children(p2).children(0).clientHeight)/2;
					obj.item(i).children(0).children(0).children(p2).children(0).style.position = "relative";
					obj.item(i).children(0).children(0).children(p2).children(0).style.top = h;
				} else {
					// complex content, adapt padding
					chd = obj.item(i).children(0).children(0).children(p2).children;
					chd = chd(chd.length-1);
					h = obj.item(i).children(0).children(0).clientHeight;
					h = (h - chd.clientHeight-chd.offsetTop)/2;
					obj.item(i).children(0).children(0).children(p2).style.paddingTop = h/2;
					obj.item(i).children(0).children(0).children(p2).style.paddingBottom = h/2;
				}
								
				// add padding to center text vertically				
				chd = obj.item(i).children(0).children(0).children(p1).children;
				chd = chd(chd.length-1);
				h = obj.item(i).children(0).children(0).clientHeight;
				h = (h - chd.clientHeight-chd.offsetTop)/2;
				obj.item(i).children(0).children(0).children(p1).style.paddingTop = h/2;
				obj.item(i).children(0).children(0).children(p1).style.paddingBottom = h/2;
			};
		};
		
		var obj = document.getElementById("all");
		obj.style.height = ha;
		obj.style.width = wa;
	};
};

doLayout();

window.onresize = doLayout;
